@extends('frontend.layouts.app')
@section('body')
    <div class="mt-5 pt-5">
        @include('frontend.home.team')
    </div>
@endsection
